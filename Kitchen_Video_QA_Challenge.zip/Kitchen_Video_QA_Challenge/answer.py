#!/usr/bin/env python3
"""
Kitchen Video QA - starter skeleton.

Matches the required CLI interface from the draft spec:
    python answer.py --videos ./clips --questions questions.json --out answers.json

This is a scaffold, not a solution. Fill in:
  - extract_frames(): your frame sampling strategy (baseline = 1 fps)
  - answer_question(): your actual model call (VLM / OCR / hybrid)

It already handles:
  - CLI args matching the spec
  - Per-clip, per-question loop
  - "not visible" as a first-class answer type
  - Logging runtime, frame counts, and a rough call/cost counter to a log file
  - Deterministic JSON output shape
"""

import argparse
import json
import time
import os
from pathlib import Path

LOG_PATH = None
_call_count = 0
_est_cost = 0.0


def log(msg: str):
    line = f"[{time.strftime('%H:%M:%S')}] {msg}"
    print(line)
    if LOG_PATH:
        with open(LOG_PATH, "a") as f:
            f.write(line + "\n")


def extract_frames(video_path: str, fps: float = 1.0):
    """
    Baseline: sample at `fps` frames per second.
    Replace with your own sampling strategy (e.g. adaptive sampling around
    motion, or higher rate near timestamp-sensitive questions).

    Return: list of (timestamp_seconds, frame) tuples.
    Stub below just returns an empty list - wire up e.g. OpenCV/ffmpeg here.
    """
    log(f"  extracting frames from {video_path} at {fps} fps (stub - implement me)")
    # Example real implementation would use cv2.VideoCapture or ffmpeg here.
    return []


def answer_question(question: dict, frames, video_path: str) -> dict:
    """
    Core answer logic. `question` looks like (see questions_schema.json):
    {
      "id": "q1",
      "video": "clip_01.mp4",
      "type": "yes_no" | "multiple_choice" | "count" | "timestamp" |
              "duration" | "structured" | "not_visible_eligible",
      "prompt": "Was a hairnet visible on the person at the packing station?",
      "options": [...]  # only for multiple_choice
    }

    Must return an answer dict matching answers_schema.json, and must be
    willing to answer "not visible" when the evidence genuinely isn't in
    frame - guessing is penalized under the scoring rubric.
    """
    global _call_count, _est_cost

    qtype = question.get("type", "structured")

    # --- STUB LOGIC: replace with real VLM/OCR calls ---
    # Example shape of what a real call might look like:
    #   _call_count += 1
    #   _est_cost += COST_PER_CALL
    #   result = call_vlm(frames, question["prompt"])

    if qtype == "yes_no":
        return {"id": question["id"], "answer": "not visible", "confidence": 0.0}
    elif qtype == "multiple_choice":
        return {"id": question["id"], "answer": "not visible", "confidence": 0.0}
    elif qtype == "count":
        return {"id": question["id"], "answer": 0, "confidence": 0.0}
    elif qtype == "timestamp":
        return {"id": question["id"], "answer": None, "confidence": 0.0}
    elif qtype == "duration":
        return {"id": question["id"], "answer": None, "confidence": 0.0}
    else:
        return {"id": question["id"], "answer": "not visible", "confidence": 0.0}


def main():
    global LOG_PATH

    parser = argparse.ArgumentParser(description="Kitchen Video QA answerer")
    parser.add_argument("--videos", required=True, help="Directory of video clips")
    parser.add_argument("--questions", required=True, help="Path to questions.json")
    parser.add_argument("--out", required=True, help="Path to write answers.json")
    parser.add_argument("--fps", type=float, default=1.0, help="Frame sampling rate")
    args = parser.parse_args()

    LOG_PATH = str(Path(args.out).with_suffix(".log"))
    open(LOG_PATH, "w").close()  # reset log

    start = time.time()
    log("Starting run")
    log(f"videos={args.videos} questions={args.questions} out={args.out} fps={args.fps}")

    with open(args.questions) as f:
        questions = json.load(f)

    video_dir = Path(args.videos)
    answers = []
    frame_cache = {}

    for q in questions:
        video_name = q["video"]
        video_path = str(video_dir / video_name)

        if video_name not in frame_cache:
            if not os.path.exists(video_path):
                log(f"  WARNING: video not found: {video_path}")
                frame_cache[video_name] = []
            else:
                frame_cache[video_name] = extract_frames(video_path, fps=args.fps)

        frames = frame_cache[video_name]
        answer = answer_question(q, frames, video_path)
        answers.append(answer)
        log(f"  answered {q.get('id')} ({q.get('type')}) -> {answer['answer']}")

    with open(args.out, "w") as f:
        json.dump(answers, f, indent=2)

    elapsed = time.time() - start
    log(f"Done. {len(answers)} answers written to {args.out}")
    log(f"Elapsed: {elapsed:.1f}s | model/API calls: {_call_count} | est. cost: ${_est_cost:.3f}")
    log(f"Budget check -> time: {elapsed:.1f}s / 1200s cap | cost: ${_est_cost:.3f} / $3.00 cap")


if __name__ == "__main__":
    main()
